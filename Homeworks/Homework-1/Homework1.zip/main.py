"""
Homework 1 for the Pirple Python-Is-Easy Course
Author: jzaunegger
Date: October 26th, 2020

About: 
    This homework was about learning about variables in Python3.
    We are instructed in how to use them, but this is an active 
    example designed to get us using them.
"""


# Declaring Variables
SongName = "Medicated"
Artist = "Wiz Khalifa"
FeaturedArtists = "Chevy Woods, Juicy J"
Album = "O.N.I.F.C"
YearReleased = 2012
Genre = "Hip Hop/Rap"
SongDurationInMinutes = 5.5 

# Printing Information
print("Song Name:", SongName)
print("Artist:", Artist)
print("Featured Artists:", FeaturedArtists)
print("Album Name:", Album)
print("Year Released:", YearReleased)
print("Musical Genre:", Genre)
print("Song Duration in Minutes:", SongDurationInMinutes)